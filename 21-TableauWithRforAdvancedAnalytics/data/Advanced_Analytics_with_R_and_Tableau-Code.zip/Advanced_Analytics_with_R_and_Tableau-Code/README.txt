Section: 1, 6, 7 - Do not contain code files

Section: 2, 3, 4, 5 - Contain Datasets that are needed